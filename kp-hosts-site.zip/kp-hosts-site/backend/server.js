const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const AGENT_URL = process.env.AGENT_URL || "http://127.0.0.1:8080";
const AGENT_TOKEN = process.env.AGENT_TOKEN || "";

const db = new Database("kp-hosts.db");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS servers (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 name TEXT NOT NULL,
 type TEXT NOT NULL,
 version TEXT,
 ram INTEGER NOT NULL DEFAULT 2048,
 status TEXT NOT NULL DEFAULT 'offline',
 directory TEXT,
 address TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
`);

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({
 secret: process.env.SESSION_SECRET || "change-this-secret",
 resave:false,
 saveUninitialized:false,
 cookie:{httpOnly:true, sameSite:"lax"}
}));

function auth(req,res,next){
 if(!req.session.userId) return res.status(401).json({error:"Não autenticado"});
 next();
}

async function agent(path, options={}){
 const headers = Object.assign({"Content-Type":"application/json"}, options.headers||{});
 if(AGENT_TOKEN) headers.Authorization = "Bearer " + AGENT_TOKEN;
 const r = await fetch(AGENT_URL + path, {...options, headers});
 const text = await r.text();
 let data; try { data = JSON.parse(text); } catch { data = {raw:text}; }
 if(!r.ok) throw new Error(data.error || data.message || `Agent HTTP ${r.status}`);
 return data;
}

app.use(express.static("public"));

app.post("/api/auth/register", async (req,res)=>{
 try{
   const {username,email,password}=req.body;
   if(!username || !email || !password || password.length < 6)
     return res.status(400).json({error:"Preencha username, email e senha de pelo menos 6 caracteres."});
   const hash=await bcrypt.hash(password,12);
   const info=db.prepare("INSERT INTO users(username,email,password_hash) VALUES(?,?,?)").run(username.trim(),email.trim().toLowerCase(),hash);
   req.session.userId=info.lastInsertRowid;
   res.json({ok:true});
 }catch(e){ res.status(400).json({error:"Usuário ou email já existe."}); }
});

app.post("/api/auth/login", async (req,res)=>{
 const {email,password}=req.body;
 const u=db.prepare("SELECT * FROM users WHERE email=?").get((email||"").toLowerCase());
 if(!u || !(await bcrypt.compare(password||"",u.password_hash)))
   return res.status(401).json({error:"Email ou senha inválidos."});
 req.session.userId=u.id;
 res.json({ok:true});
});

app.post("/api/auth/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.get("/api/me",auth,(req,res)=>{
 const u=db.prepare("SELECT id,username,email,created_at FROM users WHERE id=?").get(req.session.userId);
 res.json(u);
});

app.get("/api/servers",auth,(req,res)=>{
 res.json(db.prepare("SELECT * FROM servers WHERE user_id=? ORDER BY id DESC").all(req.session.userId));
});

app.post("/api/servers",auth,async(req,res)=>{
 try{
   const {name,type,version,ram}=req.body;
   if(!name || !["vanilla","paper","bukkit","forge","bedrock"].includes(type))
     return res.status(400).json({error:"Nome ou tipo inválido."});
   const result=db.prepare(`
     INSERT INTO servers(user_id,name,type,version,ram,status)
     VALUES(?,?,?,?,?,'provisioning')
   `).run(req.session.userId,name,type,version||"",Number(ram)||2048);
   const id=result.lastInsertRowid;
   try{
     const a=await agent("/servers/create",{method:"POST",body:JSON.stringify({
       id:String(id), name,type,version:version||"",ram:Number(ram)||2048,userId:req.session.userId
     })});
     db.prepare("UPDATE servers SET status=?,directory=?,address=? WHERE id=?")
       .run(a.status||"offline",a.directory||null,a.address||null,id);
   }catch(e){
     db.prepare("UPDATE servers SET status=? WHERE id=?").run("agent_offline",id);
     return res.status(502).json({error:"Servidor cadastrado, mas o Agent não respondeu: "+e.message,serverId:id});
   }
   res.json(db.prepare("SELECT * FROM servers WHERE id=?").get(id));
 }catch(e){res.status(500).json({error:e.message});}
});

app.post("/api/servers/:id/:action",auth,async(req,res)=>{
 const id=Number(req.params.id);
 const s=db.prepare("SELECT * FROM servers WHERE id=? AND user_id=?").get(id,req.session.userId);
 if(!s) return res.status(404).json({error:"Servidor não encontrado"});
 if(!["start","stop","restart"].includes(req.params.action)) return res.status(400).json({error:"Ação inválida"});
 try{
   const a=await agent(`/servers/${id}/${req.params.action}`,{method:"POST"});
   db.prepare("UPDATE servers SET status=? WHERE id=?").run(a.status||s.status,id);
   res.json(a);
 }catch(e){res.status(502).json({error:e.message});}
});

app.get("/api/servers/:id/console",auth,async(req,res)=>{
 const s=db.prepare("SELECT * FROM servers WHERE id=? AND user_id=?").get(Number(req.params.id),req.session.userId);
 if(!s) return res.status(404).json({error:"Servidor não encontrado"});
 try{ res.json(await agent(`/servers/${s.id}/console`)); }
 catch(e){res.status(502).json({error:e.message});}
});

app.listen(PORT,"0.0.0.0",()=>console.log(`KP HOSTS rodando em http://127.0.0.1:${PORT}`));
