# Contrato do Agent

O site espera que o Agent do celular forneça:

POST /servers/create
POST /servers/:id/start
POST /servers/:id/stop
POST /servers/:id/restart
GET  /servers/:id/console

O Agent deve criar os arquivos em /opt/jaohost/servers/<id ou slug>, baixar o servidor correspondente e iniciar o processo real.

Não coloque senhas ou tokens no frontend.
