# KP HOSTS

Projeto base para hospedagem Minecraft:
- Cadastro e login reais com SQLite
- Dashboard autenticado
- CRUD de servidores
- API para conversar com o Agent
- Criação de servidor real delegada ao Agent
- Estrutura pronta para rodar no celular com Termux

## Rodar no celular

1. Instale Node.js no Termux.
2. Entre nesta pasta.
3. Execute:
   npm install
   npm start

O painel ficará em http://127.0.0.1:3000

Para conectar o Agent real, defina:
AGENT_URL=http://127.0.0.1:8080
AGENT_TOKEN=seu_token

IMPORTANTE: este projeto não executa Minecraft dentro do Node. O Agent é responsável por criar e iniciar os processos Minecraft no celular.
