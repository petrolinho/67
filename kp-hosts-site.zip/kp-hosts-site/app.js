const $=s=>document.querySelector(s);
function show(x){$('#login').hidden=x!=='login';$('#register').hidden=x!=='register'}
async function api(url,opt={}){const r=await fetch(url,{headers:{'Content-Type':'application/json'},...opt});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Erro');return d}
async function boot(){try{const u=await api('/api/me');$('#auth').hidden=true;$('#dash').hidden=false;$('#user').textContent=u.username+' • '+u.email;load()}catch{}}
$('#login').onsubmit=async e=>{e.preventDefault();try{await api('/api/auth/login',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});boot()}catch(e){$('#msg').textContent=e.message}}
$('#register').onsubmit=async e=>{e.preventDefault();try{await api('/api/auth/register',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});boot()}catch(e){$('#msg').textContent=e.message}}
$('#create').onsubmit=async e=>{e.preventDefault();$('#createMsg').textContent='Criando servidor real...';try{await api('/api/servers',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});$('#createMsg').textContent='Servidor criado.';load()}catch(e){$('#createMsg').textContent=e.message;load()}}
async function load(){const list=await api('/api/servers');$('#servers').innerHTML=list.map(s=>`<article class="server"><h2>${esc(s.name)}</h2><div class="grid"><div class="stat">Status<br><b class="${s.status==='online'?'online':'offline'}">${esc(s.status)}</b></div><div class="stat">Tipo<br><b>${esc(s.type)}</b></div><div class="stat">RAM<br><b>${s.ram} MB</b></div><div class="stat">Endereço<br><b>${esc(s.address||'—')}</b></div></div><button onclick="act(${s.id},'start')">Iniciar</button><button onclick="act(${s.id},'stop')">Parar</button><button onclick="act(${s.id},'restart')">Reiniciar</button><button onclick="consoleView(${s.id})">Console</button><pre id="c${s.id}">Console não carregado.</pre></article>`).join('')}
async function act(id,a){try{await api(`/api/servers/${id}/${a}`,{method:'POST'});load()}catch(e){alert(e.message)}}
async function consoleView(id){try{const d=await api(`/api/servers/${id}/console`);$('#c'+id).textContent=d.output||d.console||JSON.stringify(d,null,2)}catch(e){$('#c'+id).textContent=e.message}}
async function logout(){await api('/api/auth/logout',{method:'POST'});location.reload()}
function esc(x){return String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
boot();
